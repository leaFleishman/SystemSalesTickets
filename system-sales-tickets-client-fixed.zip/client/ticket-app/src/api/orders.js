import { apiClient } from "./client";

export function createOrder({ eventId, seatId, userId }) {
  return apiClient.post("/Order", { eventId, seatId, userId }).then((res) => res.data);
}

// --- Known backend quirk -------------------------------------------------
// GET /api/Order (list) returns OrderDTO { eventId, seatId, userId } only —
// no order Id, even though GET /api/Order/{id} needs one. Same inferred-id
// workaround as events/seats (see src/api/seats.js) is applied here so the
// admin list can still link into an order's detail view.
// --------------------------------------------------------------------------
export async function getAllOrders(pageNumber = 1, pageSize = 20) {
  const res = await apiClient.get("/Order", { params: { pageNumber, pageSize } });
  const data = res.data;
  const offset = (data.pageNumber - 1) * data.pageSize;
  return {
    ...data,
    data: data.data.map((order, i) => ({ ...order, inferredId: offset + i + 1 })),
  };
}

export function getOrderById(id) {
  return apiClient.get(`/Order/${id}`).then((res) => res.data);
}
